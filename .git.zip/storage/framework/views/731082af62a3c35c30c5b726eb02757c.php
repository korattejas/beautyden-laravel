<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Appointment - <?php echo e($appointment->order_number ?? '-'); ?></title>
    <style>
        body {
            font-family: 'Segoe UI', 'DejaVu Sans', Arial, sans-serif;
            font-size: 11px;
            color: #2e2e2e;
            background: #fff;
            line-height: 1.5;
        }

        .page {
            width: 100%;
            padding: 15px;
        }

        /* ---------- HEADER ---------- */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #c59d5f;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #c59d5f, #e1c699);
            border-radius: 8px;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
        }

        .brand-text h1 {
            margin: 0;
            font-size: 18px;
            color: #2e2e2e;
            font-weight: 700;
        }

        .brand-text p {
            margin: 0;
            font-size: 10px;
            color: #6b5b73;
        }

        .header-right {
            text-align: right;
        }

        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 10px;
            color: #fff;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .badge-pending {
            background: #f59e0b;
        }

        .badge-assigned {
            background: #3b82f6;
        }

        .badge-completed {
            background: #10b981;
        }

        .badge-rejected {
            background: #ef4444;
        }

        .date-time {
            font-size: 10px;
            padding: 3px 8px;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            background: #fafafa;
            display: inline-block;
        }

        /* ---------- GRID CONTENT ---------- */
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 10px;
            background: #fafafa;
        }

        .card-title {
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 10px;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 4px;
            color: #c59d5f;
        }

        .info-row {
            display: flex;
            margin-bottom: 6px;
        }

        .info-label {
            width: 65px;
            font-size: 9px;
            color: #666;
            font-weight: 600;
            text-transform: uppercase;
        }

        .info-value {
            flex: 1;
            font-size: 11px;
            font-weight: 500;
        }

        .detail-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .detail-item {
            border: 1px solid #eee;
            border-radius: 6px;
            padding: 6px;
            text-align: center;
            background: #fff;
        }

        .detail-label {
            font-size: 8px;
            color: #888;
            text-transform: uppercase;
        }

        .detail-value {
            font-size: 11px;
            font-weight: 700;
            color: #2e2e2e;
        }

        .chip-section {
            margin-top: 8px;
        }

        .section-label {
            font-size: 9px;
            text-transform: uppercase;
            color: #555;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .chips {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
        }

        .chip {
            background: #f1eadf;
            color: #5b4636;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 9px;
            font-weight: 600;
        }

        /* ---------- NOTES ---------- */
        .notes {
            border-left: 3px solid #c59d5f;
            padding: 10px;
            margin-bottom: 15px;
            background: #fdfaf5;
            border-radius: 6px;
        }

        .notes-title {
            font-size: 10px;
            font-weight: 700;
            margin-bottom: 4px;
            text-transform: uppercase;
            color: #5b4636;
        }

        .notes-content {
            font-size: 10px;
            color: #333;
        }

        /* ---------- FOOTER ---------- */
        .footer {
            border-top: 1px solid #e5e7eb;
            padding-top: 10px;
        }

        .footer-top {
            display: flex;
            justify-content: space-between;
            font-size: 9px;
            margin-bottom: 8px;
        }

        .company-info {
            text-align: center;
            background: #fafafa;
            padding: 6px;
            border-radius: 6px;
            font-size: 9px;
            line-height: 1.4;
            color: #555;
        }

        .company-name {
            font-size: 11px;
            font-weight: 700;
            color: #2e2e2e;
        }

        @page {
            size: A4;
            margin: 10mm;
        }
    </style>
</head>

<body>
    <div class="page">
        <!-- HEADER -->
        <div class="header">
            <div class="brand">
                <div class="logo">B</div>
                <div class="brand-text">
                    <h1>BeautyDen</h1>
                    <p>Trusted Beauty Service at Your Doorstep
                    </p>
                </div>
            </div>
            <div class="header-right">
                <?php $s=$appointment->status; ?>
                <?php if($s == 1): ?>
                    <div class="badge badge-pending">Pending</div>
                <?php elseif($s == 2): ?>
                    <div class="badge badge-assigned">Assigned</div>
                <?php elseif($s == 3): ?>
                    <div class="badge badge-completed">Completed</div>
                <?php elseif($s == 4): ?>
                    <div class="badge badge-rejected">Rejected</div>
                <?php else: ?>
                    <div class="badge" style="background:#a0895c">Unknown</div>
                <?php endif; ?>
                <?php if($appointment->appointment_date || $appointment->appointment_time): ?>
                    <div class="date-time">
                        <?php if($appointment->appointment_date): ?>
                            <?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('d M, Y')); ?>

                        <?php endif; ?>
                        <?php if($appointment->appointment_time): ?>
                            <br><?php echo e($appointment->appointment_time); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- GRID CONTENT -->
        <div class="grid">
            <div class="card">
                <div class="card-title">Customer Information</div>
                <?php if($appointment->first_name || $appointment->last_name): ?>
                    <div class="info-row">
                        <div class="info-label">Name</div>
                        <div class="info-value"><?php echo e($appointment->first_name); ?> <?php echo e($appointment->last_name); ?></div>
                    </div>
                <?php endif; ?>
                <?php if($appointment->phone): ?>
                    <div class="info-row">
                        <div class="info-label">Phone</div>
                        <div class="info-value"><?php echo e($appointment->phone); ?></div>
                    </div>
                <?php endif; ?>
                <?php if($appointment->email): ?>
                    <div class="info-row">
                        <div class="info-label">Email</div>
                        <div class="info-value"><?php echo e($appointment->email); ?></div>
                    </div>
                <?php endif; ?>
                <?php if($appointment->service_address): ?>
                    <div class="info-row">
                        <div class="info-label">Address</div>
                        <div class="info-value"><?php echo e($appointment->service_address); ?></div>
                    </div>
                <?php endif; ?>
                <?php if($appointment->order_number): ?>
                    <div class="info-row">
                        <div class="info-label">Order #</div>
                        <div class="info-value"><strong><?php echo e($appointment->order_number); ?></strong></div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card">
                <div class="card-title">Order Details</div>
                <div class="detail-grid">
                    <?php if($appointment->city_name): ?>
                        <div class="detail-item">
                            <div class="detail-label">City</div>
                            <div class="detail-value"><?php echo e($appointment->city_name); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if($appointment->price): ?>
                        <div class="detail-item">
                            <div class="detail-label">Price</div>
                            <div class="detail-value">₹<?php echo e(number_format($appointment->price, 2)); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if($appointment->discount_price): ?>
                        <div class="detail-item" style="grid-column:1/-1">
                            <div class="detail-label">Discount</div>
                            <div class="detail-value">₹<?php echo e(number_format($appointment->discount_price, 2)); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(!empty($services)): ?>
                    <div class="chip-section">
                        <div class="section-label">Services</div>
                        <div class="chips">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="chip"><?php echo e($s); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(!empty($team_members)): ?>
                    <div class="chip-section">
                        <div class="section-label">Team</div>
                        <div class="chips">
                            <?php $__currentLoopData = $team_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="chip"><?php echo e($m); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- NOTES -->
        <?php if($appointment->special_notes): ?>
            <div class="notes">
                <div class="notes-title">Special Notes</div>
                <div class="notes-content"><?php echo e($appointment->special_notes); ?></div>
            </div>
        <?php endif; ?>

        <!-- FOOTER -->
        <div class="footer">
            <div class="footer-top">
                <?php if($appointment->assigned_by): ?>
                    <div>Assigned by: <strong><?php echo e($appointment->assigned_by); ?></strong></div>
                <?php endif; ?>
                <?php if($appointment->created_at): ?>
                    <div>Created:
                        <strong><?php echo e(\Carbon\Carbon::parse($appointment->created_at)->format('d M, Y H:i')); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <div class="company-info">
                <div class="company-name">BeautyDen Professional Services</div>
                +91 95747 58282 | contact@beautyden.com | www.beautyden.in
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /home2/beautyde/public_html/laravelapp/resources/views/admin/appointments/pdf.blade.php ENDPATH**/ ?>