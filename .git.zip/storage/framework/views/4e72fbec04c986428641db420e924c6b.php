<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body">
                <section id="beautyden-dashboard">
                    <div class="row match-height">

                        
                        <!-- Total Appointments -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-primary text-white shadow">
                                <a href="<?php echo e(route('admin.appointments.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="calendar" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalAppointments); ?></h2>
                                        <h5>Total Appointments</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Pending -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-warning text-white shadow">
                                <a href="<?php echo e(route('admin.appointments.index', ['status' => 1])); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="clock" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalAppointmentsPending); ?></h2>
                                        <h5>Appointments Pending</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Assigned -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.appointments.index', ['status' => 2])); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="user-check" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalAppointmentsAssigned); ?></h2>
                                        <h5>Appointments Assigned</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Completed -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-success text-white shadow">
                                <a href="<?php echo e(route('admin.appointments.index', ['status' => 3])); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="check-circle" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalAppointmentsCompleted); ?></h2>
                                        <h5>Appointments Completed</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Rejected -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-danger text-white shadow">
                                <a href="<?php echo e(route('admin.appointments.index', ['status' => 4])); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="x-circle" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalAppointmentsRejected); ?></h2>
                                        <h5>Appointments Rejected</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        
                        <!-- Contact Submissions -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-secondary text-white shadow">
                                <a href="<?php echo e(route('admin.contact-submissions.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="mail" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalContacts); ?></h2>
                                        <h5>Contact Submissions</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Service Category -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.service-category.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="layers" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalServiceCategory); ?></h2>
                                        <h5>Total Service Categories</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Services -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.service.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="briefcase" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalServices); ?></h2>
                                        <h5>Total Services</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Blogs -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.blogs.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="file-text" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalBlogs); ?></h2>
                                        <h5>Total Blogs</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Blog Categories -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.blog-category.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="folder" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalBlogCategory); ?></h2>
                                        <h5>Total Blog Categories</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Team Members -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.team.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="users" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalTeamMember); ?></h2>
                                        <h5>Total Team Members</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Hirings -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.hirings.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="briefcase" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalHirings); ?></h2>
                                        <h5>Total Hirings</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Reviews -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.reviews.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="star" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalCustomerReviews); ?></h2>
                                        <h5>Total Reviews</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Cities -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.city.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="map-pin" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalCity); ?></h2>
                                        <h5>Total Cities</h5>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Product Brand -->
                        <div class="col-md-3 col-sm-6 mb-1">
                            <div class="card text-center bg-gradient-info text-white shadow">
                                <a href="<?php echo e(route('admin.product-brand.index')); ?>" class="dashboard-card">
                                    <div class="card-body" style="color: #102365;">
                                        <i data-feather="tag" class="font-large-2 mb-1"></i>
                                        <h2 class="fw-bolder"><?php echo e($totalProductBrand); ?></h2>
                                        <h5>Total Product Brand</h5>
                                    </div>
                                </a>
                            </div>
                        </div>


                    </div>
                </section>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/beautyde/public_html/laravelapp/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>