<?php if($status_array['is_simple_active'] == 1 && $status_array['current_status'] == '1'): ?>
    <span class="badge badge-glow bg-success">Active</span>
<?php elseif($status_array['is_simple_active'] == 1 && $status_array['current_status'] == '0'): ?>
    <span class="badge badge-glow bg-danger">Inactive</span>
<?php elseif($status_array['is_simple_active'] == 1 && $status_array['current_status'] == '2'): ?>
    <span class="badge badge-glow bg-warning text-dark">Pending</span>
<?php elseif($status_array['is_simple_active'] == 1 && $status_array['current_status'] == 'completed'): ?>
    <span class="badge badge-glow bg-primary">Completed</span>
<?php elseif($status_array['is_simple_active'] == 1 && $status_array['current_status'] == 'rejected'): ?>
    <span class="badge badge-glow bg-danger">Rejected</span>
<?php elseif($status_array['is_simple_active'] == 1 && $status_array['current_status'] == 'upcoming'): ?>
    <span class="badge badge-glow bg-info text-dark">Upcoming</span>
<?php elseif($status_array['is_simple_active'] == 1 && $status_array['current_status'] == 'coming_soon'): ?>
    <span class="badge badge-glow bg-secondary">Coming Soon</span>
<?php elseif(
    $status_array['is_simple_active'] == 1 &&
        isset($status_array['current_is_popular_priority_status']) &&
        $status_array['current_is_popular_priority_status'] == '1' &&
        $status_array['current_status'] == '3'): ?>
    <span class="badge badge-glow bg-danger">High Priority</span>
<?php elseif(
    $status_array['is_simple_active'] == 1 &&
        isset($status_array['current_is_popular_priority_status']) &&
        $status_array['current_is_popular_priority_status'] == '0' &&
        $status_array['current_status'] == '3'): ?>
    <span class="badge badge-glow bg-secondary">Low Priority</span>
<?php elseif(
    $status_array['is_simple_active'] == 1 &&
        isset($status_array['current_is_new_priority_status']) &&
        $status_array['current_is_new_priority_status'] == '1' &&
        $status_array['current_status'] == '4'): ?>
    <span class="badge badge-glow bg-success">New Image</span>
<?php elseif(
    $status_array['is_simple_active'] == 1 &&
        isset($status_array['current_is_new_priority_status']) &&
        $status_array['current_is_new_priority_status'] == '0' &&
        $status_array['current_status'] == '4'): ?>
    <span class="badge badge-glow bg-dark">Old Image</span>
<?php endif; ?>
<?php /**PATH /home2/beautyde/public_html/laravelapp/resources/views/admin/render-view/datable-label.blade.php ENDPATH**/ ?>