<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Edit Service</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(trans('admin_string.home')); ?></a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo e(route('admin.service.index')); ?>">Services</a>
                                    </li>
                                    <li class="breadcrumb-item active">Edit Service</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="content-body">
                <section class="horizontal-wizard">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <form method="POST" data-parsley-validate="" id="addEditForm" role="form"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="edit_value" value="<?php echo e($service->id); ?>">
                                        <input type="hidden" id="form-method" value="edit">

                                        <div class="row row-sm">

                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Category</label>
                                                    <select name="category_id" class="form-control select2" id="category_id" required>
                                                        <option value="">Select Category</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"
                                                                <?php if($service->category_id == $category->id): ?> selected <?php endif; ?>>
                                                                <?php echo e($category->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Sub Category</label>
                                                    <select name="sub_category_id" class="form-control select2" id="sub_category_id">
                                                        <option value="">Select Sub Category</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-12 mt-2">
                                                <div class="form-group">
                                                    <label><?php echo e(trans('admin_string.name')); ?></label>
                                                    <input type="text" class="form-control" name="name"
                                                        value="<?php echo e($service->name); ?>"
                                                        placeholder="<?php echo e(trans('admin_string.name')); ?>" required>
                                                </div>
                                            </div>

                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Price</label>
                                                    <input type="text" class="form-control" name="price"
                                                        value="<?php echo e($service->price); ?>" placeholder="Price" required>
                                                </div>
                                            </div>

                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Discount Price</label>
                                                    <input type="text" class="form-control"
                                                        name="discount_price" value="<?php echo e($service->discount_price); ?>"
                                                        placeholder="Discount Price">
                                                </div>
                                            </div>

                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Duration</label>
                                                    <input type="text" class="form-control" name="duration"
                                                        value="<?php echo e($service->duration); ?>" placeholder="e.g. 45 min" required>
                                                </div>
                                            </div>

                                            <div class="col-3 mt-2">
                                                <div class="form-group">
                                                    <label>Rating</label>
                                                    <input type="number" step="0.1" class="form-control" name="rating"
                                                        value="<?php echo e($service->rating); ?>" placeholder="Rating (0-5)">
                                                </div>
                                            </div>

                                            <div class="col-3 mt-2">
                                                <div class="form-group">
                                                    <label>Reviews</label>
                                                    <input type="number" class="form-control" name="reviews"
                                                        value="<?php echo e($service->reviews); ?>" placeholder="No. of Reviews">
                                                </div>
                                            </div>

                                            <div class="col-12 mt-2">
                                                <div class="form-group">
                                                    <label>Description</label>
                                                    <textarea class="form-control" name="description" rows="4"
                                                        placeholder="<?php echo e(trans('admin_string.description')); ?>"><?php echo e($service->description); ?></textarea>
                                                </div>
                                            </div>

                                            <div class="col-12 mt-2">
                                                <div class="form-group">
                                                    <label>Includes (comma separated)</label>
                                                    <textarea class="form-control" name="includes" rows="3"
                                                        placeholder="Hair wash, Cutting, Styling">
                                                        <?php echo e(is_array($service->includes)
                                                                ? implode(',', $service->includes)
                                                                : ($service->includes
                                                                    ? implode(',', json_decode($service->includes, true))  
                                                                    : '')); ?>

                                                    </textarea>
                                                </div>
                                            </div>

                                            <div class="col-12 mt-2">
                                                <div class="form-group">
                                                    <label>Icon</label>
                                                    <?php if(isset($service->icon) && !empty($service->icon)): ?>
                                                        <div class="mb-3">
                                                            <img src="<?php echo e(asset('uploads/service/' . $service->icon)); ?>"
                                                                alt="Service Icon" style="width: 120px; height: auto;" />
                                                        </div>
                                                    <?php endif; ?>
                                                    <input type="file" class="form-control filepond" name="icon">
                                                </div>
                                            </div>

                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Status</label>
                                                    <select name="status" class="form-control" required>
                                                        <option value="1" <?php if($service->status == 1): ?> selected <?php endif; ?>>Active
                                                        </option>
                                                        <option value="0" <?php if($service->status == 0): ?> selected <?php endif; ?>>Inactive
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-6 mt-2">
                                                <div class="form-group">
                                                    <label>Priority</label>
                                                    <select name="is_popular" class="form-control" required>
                                                        <option value="1" <?php if($service->is_popular == 1): ?> selected <?php endif; ?>>High
                                                            Priority</option>
                                                        <option value="0" <?php if($service->is_popular == 0): ?> selected <?php endif; ?>>Low
                                                            Priority</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <div class="form-group mb-0 mt-3 justify-content-end"
                                                    style="text-align: right;">
                                                    <div>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(trans('admin_string.submit')); ?></button>
                                                        <a href="<?php echo e(route('admin.service.index')); ?>"
                                                            class="btn btn-secondary"><?php echo e(trans('admin_string.cancel')); ?></a>
                                                    </div>
                                                </div>
                                            </div>

                                        </div> <!-- row end -->
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script_content'); ?>
    <script>
        var form_url = 'service/store';
        var redirect_url = 'service';
        var is_one_image_and_multiple_image_status = 'is_one_image';

        $('.select2').select2({
            placeholder: "Select an option",
            allowClear: true,
            width: '100%'
        });

        let selectedCategory = $('#category_id').val();      
        let selectedSubCategory = "<?php echo e($service->sub_category_id ?? ''); ?>";

        function loadSubcategories(categoryId, selectedSubCategory = null) {
            $('#sub_category_id').empty().append('<option value="">Select Sub Category</option>');

            if (categoryId) {
                $.ajax({
                    url: '/admin/service/get-subcategories/' + categoryId,
                    type: 'GET',
                    success: function (data) {
                        $.each(data, function (key, subCategory) {
                            let selected = (selectedSubCategory == subCategory.id) ? 'selected' : '';
                            $('#sub_category_id').append('<option value="'+ subCategory.id +'" '+ selected +'>'+ subCategory.name +'</option>');
                        });

                        $('#sub_category_id').trigger('change'); 
                    }
                });
            }
        }

        $('#category_id').on('change', function () {
            let categoryId = $(this).val();
            loadSubcategories(categoryId);
        });

        if (selectedCategory) {
            loadSubcategories(selectedCategory, selectedSubCategory);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/beautyde/public_html/laravelapp/resources/views/admin/services/edit.blade.php ENDPATH**/ ?>