<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Service City Prices Report</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 11px;
            color: #333;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: center;
        }

        th {
            background: #2c3e50;
            color: #fff;
            font-size: 11px;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .desc {
            text-align: left;
            font-size: 10px;
        }
    </style>
</head>

<body>
    <h2>Service City Prices Report</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>City</th>
                <th>Category</th>
                <th>Service</th>
                <th>Price</th>
                <th>Discount Price</th>
                <th>Total Price</th>
                <th>Discount %</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $price = (float) $p->price;
                    $discount = (float) $p->discount_price;
                    $totalPrice = $discount > 0 ? $price - $discount : $price;
                    $discountPercent = ($price > 0 && $discount > 0) ? ($discount / $price) * 100 : 0;
                ?>
                <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->city_name ?? '-'); ?></td>
                    <td><?php echo e($p->category_name ?? '-'); ?></td>
                    <td><?php echo e($p->service_name ?? '-'); ?></td>
                    <td><?php echo e(number_format($price, 2)); ?></td>
                    <td><?php echo e($discount > 0 ? number_format($discount, 2) : '-'); ?></td>
                    <td><?php echo e(number_format($totalPrice, 2)); ?></td>
                    <td><?php echo e(number_format($discountPercent, 2)); ?>%</td>
                    <td><?php echo e($p->status == 1 ? 'Active' : 'Inactive'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d-m-Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home2/beautyde/public_html/laravelapp/resources/views/admin/service-city-prices/export-pdf.blade.php ENDPATH**/ ?>